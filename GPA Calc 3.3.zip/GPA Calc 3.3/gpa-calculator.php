<?php
/*
Plugin Name: GPA Calculator
Description: A simple GPA calculator plugin
Version: 3.3
Author: Muhammad Taha
*/

function gpa_calculator() {
    // Letter grade equivalents
    $grades = array(
        'A' => 4.0,
        'A-' => 3.7,
        'B+' => 3.3,
        'B' => 3.0,
        'B-' => 2.7,
        'C+' => 2.3,
        'C' => 2.0,
        'C-' => 1.7,
        'D+' => 1.3,
        'D' => 1.0,
        'F' => 0
    );

    // Check if form was submitted via AJAX
    if (isset($_POST['action']) && $_POST['action'] == 'calculate_gpa') {
        $total_credits = 0;
        $total_points = 0;
                // Loop through courses
                for ($i = 0; $i < count($_POST['grade']); $i++) {
                    $grade = strtoupper($_POST['grade'][$i]);
                    $credits = $_POST['credits'][$i];
        
                    // Check if grade is letter or numerical value
                    if (array_key_exists($grade, $grades)) {
                        // Use letter grade equivalent
                        $points = $grades[$grade] * $credits;
                    } else {
                        // Use numerical value entered by user
                        $points = floatval($grade) * $credits;
                    }
        
                    // Add to total credits and points
                    $total_credits += intval($credits);
                    $total_points += floatval($points);
                }
        
                // Calculate GPA
                if ($total_credits > 0) {
                    $gpa = round($total_points / floatval($total_credits),2);
        
                    // Return calculated GPA via AJAX
                    echo json_encode(array('gpa' => $gpa));
                } else {
                    echo json_encode(array('error' => 'Please enter valid credit values.'));
                }
        
                exit;
            }
        
            // Display form
            ?>
            <form id="gpa-form" method="post">
                <table id="courses">
                    <tr>
                        <th>Grade</th>
                        <th>Credits</th>
                        </tr>
            <tr>
                <td><input type="text" name="grade[]"></td>
                <td><input type="text" name="credits[]"></td>
            </tr>
        </table>
        <button type="button" onclick="addCourse()">Add Course</button><br><br>
        <input type="submit" name="submit" value="Calculate GPA">
    </form>

    <!-- Display calculated GPA -->
    <div id="gpa-result"></div>

    <!-- Add course function -->
    <script>
        function addCourse() {
            var table = document.getElementById("courses");
            var row = table.insertRow(-1);
            var cell1 = row.insertCell(0);
            var cell2 = row.insertCell(1);
            cell1.innerHTML = '<input type="text" name="grade[]">';
            cell2.innerHTML = '<input type="text" name="credits[]">';
        }
    </script>

    <!-- AJAX form submission -->
    <script>
        // Get form element
        var form = document.getElementById('gpa-form');

        // Listen for form submission
        form.addEventListener('submit', function(event) {
            // Prevent default form submission
            event.preventDefault();
            // Get form data
            var formData = new FormData(form);

            // Add action to form data
            formData.append('action', 'calculate_gpa');

            // Submit form data via AJAX
            var xhr = new XMLHttpRequest();
            xhr.open('POST', '<?php echo admin_url('admin-ajax.php'); ?>', true);
            xhr.onload = function() {
                if (this.status == 200) {
                    var response = JSON.parse(this.response);

                    // Check for errors
                    if (response.error) {
                        document.getElementById('gpa-result').innerHTML = '<p>' + response.error + '</p>';
                    } else {
                        document.getElementById('gpa-result').innerHTML = '<p>Your GPA is: ' + response.gpa + '</p>';
                    }
                }
            };
            xhr.send(formData);
        });
        function gpa_calculator_enqueue_styles() {
    wp_enqueue_style('gpa-calculator', plugins_url('GPA-Calc.css', __FILE__));
}
add_action('wp_enqueue_scripts', 'gpa_calculator_enqueue_styles');
    </script>

    <?php
}

// Register shortcode
add_shortcode('gpa_calculator', 'gpa_calculator');

// Register AJAX action
add_action('wp_ajax_calculate_gpa', 'gpa_calculator');
add_action('wp_ajax_nopriv_calculate_gpa', 'gpa_calculator');